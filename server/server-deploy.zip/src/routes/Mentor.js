const express = require('express');
const router = express.Router();
const User = require('../models/User');
const requireAuth = require('../middleware/requireAuth');

// Save a new mentor
router.post('/', requireAuth, async (req, res) => {
  try {
    const mentor = await User.findById(req.user.id);
    if(!mentor){
      return res.status(404).json({error: "Mentor profile not found"});
    }
    const hasCustomLink = req.body.customMeetingLink && req.body.customMeetingLink.trim();
    if (!req.body.calendarAccess && !hasCustomLink) {
      return res.status(400).json({ error: "You must either connect your Google Calendar or provide a custom video meeting link (Zoom, Meet, Teams)." });
    }

    mentor.gender = req.body.gender;
    mentor.phone = req.body.phone;
    mentor.linkedinUrl = req.body.linkedinUrl;
    mentor.referralSource = req.body.referralSource;
    if (req.body.profilePicture) mentor.profilePicture = req.body.profilePicture;
    mentor.state = req.body.state;
    mentor.timeZone = req.body.timeZone || mentor.timeZone || req.headers['x-timezone'] || 'UTC';
    mentor.additionalInfo = req.body.additionalInfo;
    mentor.university = req.body.university;
    mentor.majors = req.body.majors;
    mentor.calendarAccess = req.body.calendarAccess;
    mentor.resume = req.body.resume;
    mentor.hasCompletedProfile = true;
    mentor.mentorProfile = {
      jobTitle: req.body.jobTitle,
      employer: req.body.employer,
      industry: req.body.industry,
      yearsOfProfExp: req.body.yearsOfProfExp,
      maxMentees: req.body.maxMentees,
      frequency: req.body.frequency,
      volunteeringFor: req.body.volunteeringFor || [],
      customMeetingLink: req.body.customMeetingLink
    }
    mentor.manualAvailabilitySlots = req.body.manualAvailabilitySlots || [];
    await mentor.save()
    res.status(201).json(mentor)
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
})

// Get all mentors
router.get('/', requireAuth, async (req, res) => {
  try {
    const mentors = await User.find({ role: 'mentor', hasCompletedProfile: true})
    res.json(mentors)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
const UPDATABLE_FIELDS = ['firstName', 'lastName', 'email', 'phone', 'state', 'referralSource', 'resume', 'linkedinUrl', 'websiteUrl', 'university', 'majors', 'additionalInfo', 'manualAvailabilitySlots', 'notificationPreferences'];
const UPDATABLE_MENTOR_PROFILE_FIELDS = ['jobTitle', 'employer', 'industry', 'yearsOfProfExp', 'volunteeringFor', 'customMeetingLink', 'maxMentees', 'frequency'];
router.patch('/me',requireAuth, async (req, res) => {
  try{
    const update = {};
     UPDATABLE_FIELDS.forEach(f => { if (req.body[f] !== undefined) update[f] = req.body[f]; });
    UPDATABLE_MENTOR_PROFILE_FIELDS.forEach(f => { if (req.body[f] !== undefined) update[`mentorProfile.${f}`] = req.body[f]; });
    const mentor = await User.findByIdAndUpdate(req.user.id, update, { new: true, runValidators: true });
    res.json(mentor);
  }
      catch (err) {
    res.status(500).json({ error: err.message })
  }
    
})

module.exports = router